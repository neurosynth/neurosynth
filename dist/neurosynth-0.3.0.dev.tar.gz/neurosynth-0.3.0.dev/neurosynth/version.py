# emacs: -*- mode: python-mode; py-indent-offset: 4; tab-width: 4; indent-tabs-mode: nil -*-
# ex: set sts=4 ts=4 sw=4 et:

"""Specifies current version of NeuroSynth to be used by setup.py and __init__.py
"""

__version__ = '0.3.0.dev'
